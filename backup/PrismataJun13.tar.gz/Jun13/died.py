#!/usr/bin/python3.6
def died(masterUnitList):
	if len(masterUnitList)==0:
		return True
	return False
