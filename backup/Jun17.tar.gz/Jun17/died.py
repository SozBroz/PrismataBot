#!/usr/bin/python3.6
def died(player):
	if len(player.masterUnitList)==0:
		return True

	return False
