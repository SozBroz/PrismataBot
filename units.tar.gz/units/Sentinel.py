class Sentinel:
	__init__(self,owner):
		self.cooldown=1
		self.owner=owner
		self.hp=4
		self.frontline=False
		self.lifeSpan=-1
		self.regen=False
		self.Blocker=False
		self.Prompt=False
		self.attack=1
		self.stamina=3
		self.costDict={
		'gold':-7,
		'green':-1,
		'red':-1}
		self.onClickResCostDict={}
		self.onClickDict={}

	def __str__(self):
		return "Sentinel"

	def startTurn(self):
		self.exhaustStartOfTurn=0

	def onClick(self):
		self.exhaustOnClick=-1
