class Corpus:
	__init__(self,owner):
		self.cooldown=0
		self.owner=owner
		self.hp=2
		self.frontline=False
		self.lifeSpan=-1
		self.regen=False
		self.Blocker=False
		self.Prompt=False
		self.attack=0
		self.stamina=2
		self.costDict={
		'gold':-6,
		'red':-2}
		self.onClickResCostDict={}
		self.onClickDict={}

	def __str__(self):
		return "Corpus"

	def startTurn(self):
		self.exhaustStartOfTurn=0

	def onClick(self):
		self.exhaustOnClick=-1
