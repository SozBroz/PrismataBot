class GaussFabricator:
	__init__(self,owner):
		self.cooldown=1
		self.owner=owner
		self.hp=10
		self.frontline=False
		self.lifeSpan=8

		self.regen=False
		self.Blocker=False
		self.Prompt=False
		self.attack=0
		self.stamina=-1
		self.costDict={
		'gold':-12,
		'green':-4}
		self.onClickResCostDict={}
		self.onClickDict={}

	def __str__(self):
		return "Gauss Fabricator"

	def startTurn(self):
		self.exhaustStartOfTurn=0

	def onClick(self):
		self.exhaustOnClick=-1
