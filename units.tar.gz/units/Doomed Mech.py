class DoomedMech:
	__init__(self,owner):
		self.cooldown=1
		self.owner=owner
		self.hp=5
		self.frontline=False
		self.lifeSpan=5

		self.regen=False
		self.Blocker=False
		self.Prompt=False
		self.attack=2
		self.stamina=-1
		self.costDict={
		'gold':-9,
		'blue':-2}
		self.onClickResCostDict={}
		self.onClickDict={}

	def __str__(self):
		return "Doomed Mech"

	def startTurn(self):
		self.exhaustStartOfTurn=0

	def onClick(self):
		self.exhaustOnClick=-1
