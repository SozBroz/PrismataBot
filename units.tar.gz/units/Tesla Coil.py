class TeslaCoil:
	__init__(self,owner):
		self.cooldown=1
		self.owner=owner
		self.hp=3
		self.frontline=False
		self.lifeSpan=-1
		self.regen=False
		self.Blocker=False
		self.Prompt=False
		self.attack=3
		self.stamina=-1
		self.costDict={
		'gold':-11,
		'green':-2,
		'blue':-1}
		self.onClickResCostDict={}
		self.onClickDict={}

	def __str__(self):
		return "Tesla Coil"

	def startTurn(self):
		self.exhaustStartOfTurn=0

	def onClick(self):
		self.exhaustOnClick=-1
