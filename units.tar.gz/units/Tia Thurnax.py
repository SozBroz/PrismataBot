class TiaThurnax:
	__init__(self,owner):
		self.cooldown=0
		self.owner=owner
		self.hp=4
		self.frontline=False
		self.lifeSpan=-1
		self.regen=False
		self.Blocker=False
		self.Prompt=False
		self.attack=7
		self.stamina=3
		self.costDict={
		'gold':-7,
		'green':-3,
		'red':-1}
		self.onClickResCostDict={}
		self.onClickDict={}

	def __str__(self):
		return "Tia Thurnax"

	def startTurn(self):
		self.exhaustStartOfTurn=0

	def onClick(self):
		self.exhaustOnClick=-1
