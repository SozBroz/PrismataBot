#!/usr/bin/python3.6
import sys #Probably for exits on future try catchs or someshit
turnHistory=[]
remainingOptions=[]
turnUnitIterator=[0]
unitCostDict={
'Engineer':{'gold':2},
'Drone':{'gold':3,'energy':1},
'Animus':{'gold':6},
'Tarsier':{'gold':4,'red':1},
'Perforator':{'gold':3,'red':1},
'Shadowfang':{'gold':8,'red':3}
}
unitList=[]
for a in unitCostDict:
	unitList.append(a)

numOfUnits=len(unitCostDict)

def unitStrToClassFromFile(owner,initUnitOptions): #
	initUnitOptions[1]=range(0,int(initUnitOptions[1]))
	initUnitOptions[2]=int(initUnitOptions[2].strip())
	owner.unitStrToClass(initUnitOptions[0])
	owner.resUnits[-1].cooldown=initUnitOptions[2]
	
def canBuyUnitCheck(resourcesList,unit):
	#UNIT=CAPITALIZED UNIT NAME
	#print("unit:",unit)
	for resource in unitCostDict[unit]:
		if resourcesList[resource]<unitCostDict[unit][resource]:
			return(False)

	return(True)

def attacking(p1,p2):
	while p2!=[] and p1.resDict['attack']>= p2[0]:
		p1.resDict['attack']-=p2[0]
		p2=p2[1:]

	return p1,p2

def moveIncrementer(player,turnCounter):
	tempResources=player.resDict # To track purchases
	foundNewMove=True #Tracks if progress was made ###INITIALIZE AS TRUE TO ENTER WHILE LOOP
	toBeBoughtThisTurn=turnHistory[turnCounter][:-1] #what was bought this turn last time INITIALIZATION
	print("turnHistory",turnHistory)
	doneWithUnitsUpTo=unitList.index(turnHistory[turnCounter][:-1])#remember which unit was bought last
	for unit in toBeBoughtThisTurn: #Commit the resources except the last 
		player.buyUnit(unit) #commit the purchases to update resources.

	tempResources=player.resDict #restore temp of resources
	######NOW YOU HAVE THE LAST PLAYED MOVE OF TURN TO ITERATE SANS THE LAST BOUGHT UNIT
	######Clear to be bought this turn
	while foundNewMove:
		foundNewMove=False
		for newUnit in unitList[doneWithUnitsUpTo:]: #Check for other UNITS TO BUY USING THE REMEMBERED UNIT
			if canBuyUnitCheck(tempResources,newUnit): #If you find a new unit you can buy
				toBeBoughtThisTurn.append(newUnit) #buy and commit
				player.buyUnit[newUnit] #
				tempResources=player.resDict
				foundNewMove=True
				break

	

def genPurchaseBruteForce(player):
	tempResources=player.resDict # To track purchases
	try:
		turnHistory[turnCounter]  #Check if we should proceed
		######TURN HAS HISTORY !!!! WORK WITH EXISTING HISTORY TO FIND CHANGE TO MAKE
		######YOU ONLY ENTER HERE AFTER FIRST RUN THROUGH OF GAME
		######MAKE SURE ONLY LAST TURN CHANGES UNTIL YOU EXHAUST EVERYTHING IN FINAL TURN
		######MAKE CHANGE TO PREVIOUS TURN THEN RE-EXHAUST
		######MAKING CHANGES TO LAST MOVE FIRST
		######IF THIS SHIT WORKS HOLY FUCK
		for i in range(turnCounter,0,-1):
			if turnHistory[i] != []: #Work with this turn
				return moveIncrementer(player,i)
		
	except IndexError: # TURN DOESN'T HAVE HISTORY !!!!! FIRST RUNTHROUGH OF TURN
		toBeBoughtThisTurn=[] 
		somethingToBuy=True  #get in first time
		while somethingToBuy:					
			somethingToBuy=False #set to haven't found anything to buy
			for i in unitList:
				if canBuyUnitCheck(tempResources,i):
					print(i)
					toBeBoughtThisTurn.append(i)
					player.buyUnit(i)
					tempResources=player.resDict
					somethingToBuy=True #found something to buy

		
		print("line 94: toBeBoughtThisTurn",toBeBoughtThisTurn)
		turnHistory.append(toBeBoughtThisTurn) #take note of everything bought this round

		
	
def autoTurn(player1,player2):
	#Stage 1 - Resources
	#Dumb: always clicks on resource units.
	
	for a in player1.resUnits:
		a.onClick()

	#Stage 2 - Attackers #####
	#Dumb attacking: click everything
	#Smart Attacking should be easy to make with dumb list of blockers hp
	player1,player2=attacking(player1,player2)

	#Stage 3 - BruteForce buying
	genPurchaseBruteForce(player1)
	return player1,player2

	
class player:
	def __init__(self):
		self.resDict={
		'gold':0,
		'blue':0,
		'red':0,
		'energy':0,
		'attack':0,
		'defence':0 }
		self.resUnits=[]
		self.otherUnits=[]
 
	def turnEnd(self):
		self.resDict['energy']=0
		self.resDict['blue']=0
		self.resDict['red']=0
		for a in self.resUnits:
			a.cooldown+=1

		for a in self.otherUnits:
			a.cooldown+=1	

	def startTurn(self):
		for a in self.resUnits:
			if a.cooldown>=0:
				a.startTurn()

		for a in self.otherUnits:
			if a.cooldown<=0:
				a.startTurn()

	def unitStrToClass(self,unit):
		if unit == "Drone":
			self.resUnits.append(Drone(self))

		elif unit == "Engineer":
			self.resUnits.append(Engineer(self))
				
		elif unit == "Animus":
			self.resUnits.append(Animus(self))

		elif unit == "Tarsier":
			self.resUnits.append(Tarsier(self))

		elif unit == "Perforator":
			self.resUnits.append(Perforator(self))
				
		else:
			print(unit,"NOT IN unitStrToClass")
			sys.exit(1)

	def buyUnit(self,unit):
	#UNIT=CAPITALIZED UNIT NAME
		for resource in unitCostDict[unit]:
			#print(self.resDict[resource])
			#print(unitCostDict[unit][resource])
			if self.resDict[resource]<unitCostDict[unit][resource]:
				#print("Not Enough",resource)
				return(1)
		#Buy
		for resource in unitCostDict[unit]:
			self.resDict[resource]-=unitCostDict[unit][resource]
		
		self.unitStrToClass(unit)

	def displayUnits(self):
		temp=[]
		count=[]
		for a in self.resUnits:
			if str(a) in temp:
				count[temp.index(str(a))]+=1
			else:
				temp.append(str(a))
				count.append(1)
		for a in range(0,len(temp)):
			print("Unit:",temp[a],count[a])

	def displayResources(self):
		print("Gold:", self.resDict['gold'])
		print("Blue:", self.resDict['blue'])
		print("Red:", self.resDict['red'])
		print("Energy:" , self.resDict['energy'])

	def __str__(self):
		self.displayUnits()
		self.displayResources()
		return(str())

class Engineer:
	def __init__(self,owner):
		self.cooldown=-1
		self.hp=1
		self.owner=owner
			
	def __str__(self):
		return "Engineer"		

	def startTurn(self):
		self.owner.resDict["energy"]+=1
		self.owner.resDict["defence"]+=self.hp
		
	def onClick(self):
		pass

class Drone:
	def __init__(self,owner):
		self.cooldown=-1
		self.hp=1
		self.owner=owner
		self.cooldown=-1
	
	def __str__(self):
		return "Drone"	

	def startTurn(self):
		self.owner.resDict["defence"]+=self.hp
		
	def onClick(self):
		if self.cooldown>=0:
			self.owner.resDict["defence"]-=self.hp
			self.owner.resDict["gold"]+=1
		

class Animus:
	def __init__(self,owner):
		self.cooldown=-1
		self.hp=2
		self.owner=owner

	def __str__(self):
		return "Animus"

	def startTurn(self):
		self.owner.resDict["red"]+=2
		
	def onClick(self):
		pass

class Tarsier:
	def __init__(self,owner):
		self.owner=owner
		self.cooldown=-2
		self.hp=1

	def __str__(self):
		return "Tarsier"

	def startTurn(self):
		self.owner.attack+=1

	def onClick(self):
		pass	

class Perforator:
	def __init__(self,owner):
		self.cooldown=-1
		self.hp=2
		self.owner=owner

	def __str__(self):
		return "Perforator"

	def startTurn(self):
		self.owner.defence+=self.hp

	def onClick(self):
		if self.cooldown>=0:
			self.owner.defence-=self.hp
			self.owner.red-=1
			self.owner.attack+=1

class Shadowfang:
	def __init__(self,owner):
		self.cooldown=-1
		self.hp=1
		self.owner=owner

	def __str__(self):
		return "Shadowfang"

	def startTurn(self):
		self.owner.attack+=2

	def onClick(self):
		pass

##Initialize		
turnCounter=0
won=False
isPossible=True
p1INIT=player()
p2INIT=[2,1]
with open("Maps/Plasma Bombs Expert.txt") as f:
	for line in f:
		unitStrToClassFromFile(p1INIT,line.split(","),)

while not won:
	turnCounter=0
	p1=p1INIT
	p2=p2INIT
	while turnCounter<6:
		p1.startTurn()
		p1,p2=autoTurn(p1,p2)
		p1.turnEnd()
		if p2==[]:
			won=True
			break

		turnCounter+=1

	if turnHistory==[[],[],[],[],[]]:
		print("not possible")
		break

#### DUMP WINNING COMBINATION INTO FILE


#file.write(numbers)

###
#Check resources

